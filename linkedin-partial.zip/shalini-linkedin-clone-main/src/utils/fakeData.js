export const userData = {
    id: 1,
    name: 'Shalini .',
    email: '',
    password: '',
    accessToken: 'ieupro7834sdufspdoifjskeiruo3i45u3io4u3poius98r',
    job: 'Software Developer at Company',
    address: 'Bengaluru, karnataka, India',
    connection: '500+',
    experience: [
        {
            title: 'Software Developer',
            company: 'doodleblue innvations - Full-time',
            time: 'Nov 2021 - Present - 11 mos',
        },
        {
            title: 'Associate Software Engineer',
            company: 'doodleblue innvations - Full-time',
            time: 'Nov 2021 - Present - 11 mos',
        },
        {
            title: 'Student',
            company: 'Dayananda Sagar College of Engineering',
            time: 'Nov 2021 - Present - 11 mos',
        },
        {
            title: 'Full stack developer',
            company: 'doodleblue innvations - Full-time',
            time: 'Nov 2021 - Present - 11 mos',
        },
        {
            title: 'Internet of Things Intern',
            company: 'bytestorm pvt ltd',
            time: 'Nov 2021 - Present - 11 mos',
        },
    ],
    education: [
        {
            title: 'Dayananda Sagar College of Engineering',
            company: 'Bachelor of Technology- BTech, elctronics and instrumentation',
            time: '2016 - 2020',
        },
    ],
    certifications: [
        {
            title: 'HTML',
            company: 'Sololearn',
            time: 'Issued Jan 2020 - No Expiration Data'
        },
        {
            title: 'C#',
            company: 'Sololearn',
            time: 'Issued Jan 2020 - No Expiration Data'
        },
    ],
    skill: [
        {
            title: 'HTML5',
            value: 90
        },
        {
            title: 'css3',
            value: 85
        },

        {
            title: 'JS',
            value: 80
        },
        {
            title: 'React',
            value: 90
        }, {
            title: 'Python',
            value: 70
        },
        {
            title: 'c#',
            value: 75
        },

    ]
}