import mock from './mock';
import './user/userData';

mock.onAny().passThrough();
